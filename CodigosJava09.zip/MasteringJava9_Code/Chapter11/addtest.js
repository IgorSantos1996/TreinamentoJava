var addtest = function()
{
  print("Simple Test");
  print("This JavaScript program adds the numbers 300 and 19.");
  print("Addition results = " + (300 + 19));
}
addtest();