module stackwalker {
  exports packt.java9.deep.stackwalker.logretriever;
  exports packt.java9.deep.stackwalker.myrestrictivelibrary;
  exports packt.java9.deep.stackwalker.externalcode;
}