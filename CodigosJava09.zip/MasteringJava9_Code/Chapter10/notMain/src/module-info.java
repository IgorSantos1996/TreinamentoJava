module notMain {
    requires mylibrary;

}